# Mobile check

Responsive design is a stated requirement, so it is worth five minutes of
verification rather than assuming it works.

## How to check

Firefox: **Ctrl+Shift+M** (responsive design mode), or just drag the window
narrow. Test at three widths:

| Width | Represents |
|---|---|
| 375px | iPhone SE — the tightest case |
| 768px | Tablet portrait |
| 1024px | Small laptop |

## What to look for on each screen

**Sidebar** — below `md` it should collapse into a hamburger in the top bar.
Tapping it opens a drawer; tapping a link closes it again.

**Dashboard** — metric cards stack one per row at 375px, and the two lower
panels stack rather than sitting side by side.

**Projects** — the table will scroll horizontally. That is acceptable for
tabular data; what matters is that nothing is clipped and the page itself does
not scroll sideways.

**Deliverables / Budget** — project cards stack. The summary figures on the
card face are hidden below `md` by design, so check the cards still read
sensibly without them.

**Resources** — cards go to one per row. Long names and emails should truncate
with an ellipsis, not overflow.

**Dialogs** — should be usable at 375px: fields full width, buttons reachable
without horizontal scrolling.

**Login** — the left panel is hidden below `md`; the form should centre.

## Things that commonly break

- A wide table forcing the whole page to scroll sideways — check by scrolling
  right and confirming the sidebar and header stay put
- Long project names pushing a card wider than the screen
- A dialog taller than the viewport with the Save button out of reach

## If something is wrong

Note it rather than fixing it under time pressure the night before. A known,
stated limitation reads far better than a rushed change that breaks the demo.
