# Demo script

Roughly eight minutes, structured so the strongest material lands even if you
are cut short. Sign in fresh beforehand — sessions expire after eight hours.

**Before you start:** have the app open at the login screen, and a terminal
ready in a second window.

---

## 1 · The problem, in one sentence (20s)

> "ACME runs projects across several departments with no shared view of them.
> Managers can't see which work is blocked, who is over-allocated, or whether
> spend is tracking to plan — so deadlines slip before anyone notices. This is
> the platform that answers those questions."

Don't read the requirements back at them. State the problem and move.

---

## 2 · Sign in as a manager (40s)

Click **Michael Rao** on the login screen.

> "Three roles. This is a project manager — he lands on his own portfolio, not
> the whole organisation."

Point at the dashboard:

> "Four numbers, and then the thing that actually matters: **Needs attention**.
> Two projects at risk, and the deliverables that are blocked — each one says
> *why*. That panel is the product in miniature."

---

## 3 · The dependency chain — your strongest feature (90s)

**Projects → Payments API v2 → scroll to Delivery Sequence.**

> "Deliverables depend on each other. This is the delivery sequence — the
> longest chain is the critical path."

Point at a blocked card:

> "Load and soak testing is blocked because Core payments service is only 55%
> done. That's the bottleneck. The system worked that out — nobody set a flag."

Now prove it is enforced, not decorative. Open the blocked deliverable:

> "And because the dependency isn't finished, the status and completion fields
> are locked. You cannot record progress on work that can't legitimately have
> started."

**If they look interested, this is the moment to go to the terminal:**

```bash
curl -X PUT http://localhost:3001/api/deliverables/<id> \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"status":"completed"}'
```

> "Same rule from the API, bypassing the interface entirely. 400, and it names
> what's blocking it. The UI is a convenience; the rule lives in the service."

---

## 4 · Capacity, and preventing over-allocation (45s)

**Resources.**

> "Everyone's allocation against their capacity. Omar is at 95% — nearly full.
> Michael has nothing allocated."

**Back to a project → Team → Assign member.**

> "When a manager builds a team, the list is sorted by who has capacity left,
> and it won't let you over-commit someone. It prevents the conflict rather
> than reporting it afterwards."

---

## 5 · Roles are real, not cosmetic (60s)

**Sign out → sign in as Sana Kapoor (member).**

> "Same application, different job. She sees her own work. No create buttons
> anywhere — and on her own deliverable she gets a restricted dialog: status
> and completion only. She can't reassign it or move the deadline."

Change a percentage:

> "And a progress move requires a note. A number on its own tells you nothing
> a week later — this builds a history on the deliverable, and her manager
> replies on the same thread."

**Sign in as Alice (admin).**

> "The administrator is deliberately *not* a business actor. She can see
> everything and manage accounts, but she cannot create projects or propose
> budgets — that's a manager's responsibility. Privilege and responsibility
> are separate axes."

Show the banner on Projects explaining exactly that.

---

## 6 · The report (30s)

**Any project → Status report → Print.**

> "What a manager hands a stakeholder. It opens with the judgement — on track
> or needs attention, and why — then deliverables, the sequence, budget
> variance, and the team. Printed through the browser, so it's a clean PDF on
> any machine without shipping a PDF library."

---

## 7 · Tests — close on this (60s)

Terminal:

```bash
python3.13 -m pytest backend/tests -v --ignore=backend/tests/integration
cd frontend && npm test
python3.13 -m pytest backend/tests/integration -v
```

> "131 tests. Ninety unit tests over the decision logic — permissions, risk
> detection, dependency rules. Forty-one integration tests against the live API
> with a real database, nothing mocked."

Then the line that matters:

> "Every authentication test is an attack executed for real. Deleting a project
> with no token, a forged admin token, an expired session — the service refuses
> all of them, and the tests prove it rather than asserting that a helper
> function would have."

If asked what's missing, answer straight:

> "End-to-end browser testing. It's the clearest gap and it's documented in
> TESTING.md as the next thing I'd build."

---

## Questions you should expect

**"Why can't the admin create projects?"**
> Privilege and responsibility are different things. An admin who can do
> everything makes the role meaningless and puts delivery decisions with
> whoever holds the highest access. Here the admin runs the platform; managers
> run the work.

**"How are passwords stored?"**
> bcrypt, cost factor 12, unique salt per user. It's one-way — the original
> can't be recovered from the hash even with database access. Login verifies by
> re-hashing and comparing, never by decrypting. `password_hash` is never
> returned by any endpoint, and failed logins return an identical message
> whether the email or the password was wrong, so you can't enumerate accounts.

**"What was hardest?"**
> After adding JWT verification everything returned 401 with a token that was
> demonstrably valid. The cause was a header whitelist in the workshop's dev
> proxy — it predates authentication and forwarded only four headers, dropping
> `Authorization`. The lesson: when the client is right and the server is
> right, the fault is in the layer between them. The service now also accepts
> `X-Auth-Token`, because Lambda Function URLs reserve `Authorization` for IAM
> and can consume it.

**"What would you do next?"**
> End-to-end tests, a proper `project_members` join table instead of storing
> team membership as text, and refresh tokens so a session renews instead of
> forcing a re-login.

**"Where did you use AI?"**
> Throughout, and I'd say so. What I'd point to is the debugging — the
> dependency-chain rules, the header issue, the Python-version mismatch in the
> Lambda packaging. Those needed reading logs and forming a hypothesis, not
> generating code.

---

## If you only get three minutes

1. Dashboard → **Needs attention**
2. **Delivery Sequence** → the blocked deliverable and why
3. `npm test` → the green wall

That's the problem, the insight, and the evidence.
