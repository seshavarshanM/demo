# Testing

## Running the tests

```bash
# Backend — 41 tests
python3.13 -m pytest backend/tests -v

# Frontend — 49 tests
cd frontend && npm test
```

Both suites run in about a second and need no database, no running server and
no network. That is deliberate: tests that depend on infrastructure get skipped
when the infrastructure is inconvenient, and tests that get skipped stop
protecting anything.

## What is covered, and why

The suite targets **decisions and calculations** — the code where being wrong
causes real damage. Rendering is left to the component libraries that own it.

### Authentication (`backend/tests/test_auth.py` — 15 tests)

Every test here describes an attack that would otherwise succeed silently:

| Test | What it prevents |
|---|---|
| Request with no token is rejected | Anonymous access to every endpoint |
| Token signed with a different secret is rejected | Forging an admin token |
| Tampered payload is rejected | Editing your own role inside a token |
| Expired token is rejected | Sessions that never end |
| Identity is read from the token, not the request | Claiming to be another user in the request body |

It also covers transport realities: header casing differs between API Gateway,
Lambda Function URLs and the local dev proxy, and Function URLs can consume the
`Authorization` header entirely — so `X-Auth-Token` is accepted as a fallback.
That behaviour exists because of a real failure, and the tests keep it fixed.

### Authorization (`backend/tests/test_authorization.py` — 15 tests)

The role model asserted end to end:

- **Administrators are not business actors.** They cannot create projects or
  propose budgets; they keep compliance deletion, account management and the
  audit trail.
- **Managers are scoped to what they own.** A manager acting on another
  manager's project is refused.
- **Members do the work.** They are refused every structural action.

### Business rules (`backend/tests/test_business_rules.py` — 11 tests)

- Status and completion can never contradict each other — 100% forces
  *Completed*, and a *Completed* item dropped below 100% reopens. This encodes
  a bug found during development, where a deliverable read "Completed" at 70%.
- Project completion is the average of its deliverables, never a typed number.

### Permissions in the interface (`frontend/src/__tests__/permissions.test.js` — 18 tests)

The frontend rules mirror the backend rules. These tests exist so the interface
never offers a button the API will reject — the two are asserted against the
same role model.

### Dependencies (`frontend/src/__tests__/dependencies.test.js` — 18 tests)

- Finish-to-start: work cannot record progress until its predecessor is done
- Blocking is derived, so it stays true without anyone maintaining a flag
- Cycles are impossible: a deliverable cannot depend on itself or on an ancestor
- Chain building never loses a deliverable, and separates genuinely independent
  work from parallel branches sharing a predecessor

### Risk detection (`frontend/src/__tests__/risk.test.js` — 13 tests)

Boundary behaviour of the at-risk rule: overdue and unfinished, or within
fourteen days at under seventy percent. Completed projects are never flagged,
and the reason given is checked, not just the verdict.

## What is deliberately not covered

Being explicit about the gaps is more useful than an inflated number:

- **Component rendering.** Whether Material UI draws a button is Material UI's
  responsibility.
- **Database round-trips.** The SQL is thin; the logic it serves is unit-tested
  above. Integration tests against a live Postgres would add real value and are
  the first thing worth adding next.
- **End-to-end browser journeys.** A Playwright or Cypress pass over
  sign-in → create project → assign work → report would catch wiring mistakes
  that unit tests cannot see. Not attempted within the workshop timebox.
- **The Lambda handlers themselves.** Their decision logic is extracted and
  tested; the HTTP plumbing around it is verified by hand with `curl`.

## Manual verification

Alongside the automated suite, each API was exercised directly, including the
cases that matter most:

```bash
# Without a token — must be 401
curl -i -X DELETE http://localhost:3001/api/projects/<id>

# With a forged token — must be 401
curl -i http://localhost:3001/api/projects -H "Authorization: Bearer fake.token.here"

# Completing work whose dependency is unfinished — must be 400
curl -i -X PUT http://localhost:3001/api/deliverables/<id> \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"status":"completed"}'
```
