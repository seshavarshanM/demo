import { useState, useEffect, useCallback } from 'react'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Avatar from '@mui/material/Avatar'
import TextField from '@mui/material/TextField'
import Button from '@mui/material/Button'
import Skeleton from '@mui/material/Skeleton'
import Divider from '@mui/material/Divider'
import SendIcon from '@mui/icons-material/SendRounded'
import { deliverableService } from '../services/deliverableService'
import { palette, statusToken, font } from '../theme/tokens'

const initials = (n = '') => n.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
const avatarColor = (n = '') =>
  ['#16161A', '#4A4A52', '#1B4B8F', '#15633C', '#9C3A06', '#93231C'][(n.charCodeAt(0) || 0) % 6]

function when(ts) {
  if (!ts) return ''
  const then = new Date(String(ts).replace(' ', 'T'))
  const mins = Math.round((Date.now() - then.getTime()) / 60000)
  if (Number.isNaN(mins)) return String(ts)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  if (mins < 1440) return `${Math.round(mins / 60)}h ago`
  return then.toLocaleDateString(undefined, { day: 'numeric', month: 'short' })
}

const KIND_LABEL = { progress: 'Progress', remark: 'Manager remark', note: 'Note' }

/**
 * The history of a deliverable: how far it moved, when, and what the person
 * doing the work said about it. A percentage on its own tells you nothing a
 * week later — the note is the part that survives.
 */
export default function ProgressTimeline({ deliverableId, canPost = false, compact = false }) {
  const [entries, setEntries] = useState([])
  const [loading, setLoading] = useState(true)
  const [note, setNote] = useState('')
  const [posting, setPosting] = useState(false)
  const [error, setError] = useState('')

  const load = useCallback(() => {
    if (!deliverableId) return
    setLoading(true)
    deliverableService.updates(deliverableId)
      .then(setEntries)
      .catch(e => setError(e?.response?.data?.message || e.message))
      .finally(() => setLoading(false))
  }, [deliverableId])

  useEffect(() => { load() }, [load])

  const post = async () => {
    const text = note.trim()
    if (!text) return
    setPosting(true); setError('')
    try {
      await deliverableService.postUpdate(deliverableId, text)
      setNote('')
      load()
    } catch (e) {
      setError(e?.response?.data?.message || e.message)
    } finally {
      setPosting(false)
    }
  }

  if (loading) {
    return <Box sx={{ py: 1 }}>{[1, 2].map(i => <Skeleton key={i} height={40} />)}</Box>
  }

  return (
    <Box>
      {canPost && (
        <Box sx={{ display: 'flex', gap: 1, mb: entries.length ? 2 : 0 }}>
          <TextField
            fullWidth size="small" multiline maxRows={3}
            placeholder="Add an update — what changed, and anything blocking you"
            value={note} onChange={e => setNote(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) post() }}
          />
          <Button variant="contained" onClick={post} disabled={posting || !note.trim()}
            sx={{ alignSelf: 'flex-start', minWidth: 0, px: 1.5 }}>
            <SendIcon sx={{ fontSize: 17 }} />
          </Button>
        </Box>
      )}

      {error && <Typography variant="caption" color="error" sx={{ display: 'block', mb: 1 }}>{error}</Typography>}

      {entries.length === 0 ? (
        <Typography variant="body2" color="text.secondary" sx={{ py: compact ? 1 : 2 }}>
          No updates yet. The first progress change will appear here.
        </Typography>
      ) : (
        <Box sx={{ position: 'relative', pl: 2.5 }}>
          {/* Spine */}
          <Box sx={{
            position: 'absolute', left: 11, top: 6, bottom: 6, width: '1px',
            bgcolor: palette.border,
          }} />

          {entries.map((e, i) => {
            const moved = e.kind === 'progress' && e.to_pct !== null
            const delta = moved ? Number(e.to_pct) - Number(e.from_pct || 0) : 0
            return (
              <Box key={e.id} sx={{ position: 'relative', pb: i === entries.length - 1 ? 0 : 2.25 }}>
                <Avatar sx={{
                  position: 'absolute', left: -20, top: 0, width: 22, height: 22,
                  fontSize: '0.5625rem', bgcolor: avatarColor(e.author_name),
                  border: `2px solid ${palette.surface}`,
                }}>
                  {initials(e.author_name)}
                </Avatar>

                <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 0.75, flexWrap: 'wrap', mb: 0.25 }}>
                  <Typography variant="subtitle2">{e.author_name}</Typography>
                  {moved && (
                    <Typography component="span" sx={{
                      fontFamily: font.mono, fontSize: '0.75rem', fontWeight: 500,
                      color: delta >= 0 ? statusToken('completed').fg : statusToken('at_risk').fg,
                    }}>
                      {e.from_pct}% → {e.to_pct}%
                    </Typography>
                  )}
                  {e.kind !== 'progress' && (
                    <Typography component="span" variant="caption" sx={{
                      px: 0.625, py: 0.125, borderRadius: 0.5,
                      bgcolor: e.kind === 'remark' ? palette.accentSoft : palette.surfaceAlt,
                      color: e.kind === 'remark' ? palette.accentInk : palette.inkSubtle,
                      fontWeight: 600, fontSize: '0.625rem',
                    }}>
                      {KIND_LABEL[e.kind] || e.kind}
                    </Typography>
                  )}
                  <Typography variant="caption" sx={{ ml: 'auto' }}>{when(e.created_at)}</Typography>
                </Box>

                <Typography variant="body2" sx={{ color: palette.inkMuted }}>{e.note}</Typography>
              </Box>
            )
          })}
        </Box>
      )}
    </Box>
  )
}
