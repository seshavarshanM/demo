import api from './api'

const BASE = '/resources'

export const resourceService = {
  getAll:  (params = {}) => api.get(BASE, { params }).then(r => r.data),
  getById: (id)          => api.get(`${BASE}/${id}`).then(r => r.data),
  create:  (data)        => api.post(BASE, data).then(r => r.data),
  update:  (id, data)    => api.put(`${BASE}/${id}`, data).then(r => r.data),
  remove:  (id)          => api.delete(`${BASE}/${id}`).then(r => r.data),
}
