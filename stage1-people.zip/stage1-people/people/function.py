"""
People service — unified identity for ACME Project Hub.

One `people` record = one human. Used for:
  - login (bcrypt-hashed password + JWT session token)
  - resource allocation (capacity / allocated hours)
  - assignee & manager references across projects and deliverables

Routes (via proxy at /api/people):
  GET    /api/people                 list all (never returns password_hash)
  GET    /api/people/{id}            single person
  POST   /api/people                 create person (hashes password)
  PUT    /api/people/{id}            update person
  DELETE /api/people/{id}            remove person
  POST   /api/people/login           { email, password } -> { token, user }
  POST   /api/people/seed            populate demo data (idempotent)
"""
import json
import os
import datetime
import bcrypt
import jwt
from postgres_service import execute_query

HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
}

# In production this would come from AWS Secrets Manager, never a literal.
JWT_SECRET = os.environ.get('JWT_SECRET', 'acme-workshop-dev-secret-change-in-prod')
JWT_ALGO = 'HS256'
TOKEN_HOURS = 8

PUBLIC_FIELDS = """
    id, employee_id, name, email, role, title, department,
    capacity_hours, allocated_hours, projects, phone, location,
    bio, joined_date, created_at, updated_at
"""


def respond(status, body):
    return {'statusCode': status, 'headers': HEADERS, 'body': json.dumps(body, default=str)}


def get_method(event):
    return (
        event.get('httpMethod')
        or (event.get('requestContext') or {}).get('http', {}).get('method')
        or 'GET'
    ).upper()


def get_path(event):
    return event.get('path') or event.get('rawPath') or ''


def path_parts(event):
    """Segments after /api/people — e.g. ['login'] or ['<uuid>']."""
    path = get_path(event)
    return [p for p in path.split('/') if p and p not in ('api', 'people')]


# ── Password hashing (bcrypt: one-way, salt embedded in the hash) ──────────
def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode('utf-8'), bcrypt.gensalt(rounds=12)).decode('utf-8')


def verify_password(plain: str, stored_hash: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode('utf-8'), stored_hash.encode('utf-8'))
    except Exception:
        return False


def make_token(person):
    payload = {
        'sub': str(person['id']),
        'employee_id': person.get('employee_id'),
        'email': person['email'],
        'role': person['role'],
        'name': person['name'],
        'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=TOKEN_HOURS),
        'iat': datetime.datetime.now(datetime.timezone.utc),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)


def init_db():
    execute_query("""
        CREATE TABLE IF NOT EXISTS people (
            id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id     VARCHAR(20)  UNIQUE NOT NULL,
            name            VARCHAR(255) NOT NULL,
            email           VARCHAR(255) UNIQUE NOT NULL,
            password_hash   TEXT         NOT NULL,
            role            VARCHAR(20)  NOT NULL DEFAULT 'member',
            title           VARCHAR(255) DEFAULT '',
            department      VARCHAR(255) DEFAULT '',
            capacity_hours  INTEGER      DEFAULT 40,
            allocated_hours INTEGER      DEFAULT 0,
            projects        TEXT         DEFAULT '',
            phone           VARCHAR(50)  DEFAULT '',
            location        VARCHAR(255) DEFAULT '',
            bio             TEXT         DEFAULT '',
            joined_date     DATE,
            created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
            updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
        )
    """)


def handler(event, context):
    try:
        init_db()
        method = get_method(event)
        parts = path_parts(event)
        qp = event.get('queryStringParameters') or {}
        body = json.loads(event['body']) if event.get('body') else {}

        if method == 'OPTIONS':
            return respond(200, {})

        # ── POST /api/people/login ────────────────────────────────────────
        if method == 'POST' and parts and parts[0] == 'login':
            email = (body.get('email') or '').strip().lower()
            password = body.get('password') or ''
            if not email or not password:
                return respond(400, {'message': 'Email and password are required'})

            rows = execute_query(
                "SELECT * FROM people WHERE LOWER(email) = %s", (email,)
            )
            if not rows or not verify_password(password, rows[0]['password_hash']):
                # Same message either way — don't reveal which part was wrong.
                return respond(401, {'message': 'Invalid email or password'})

            person = rows[0]
            person.pop('password_hash', None)
            return respond(200, {'token': make_token(person), 'user': person})

        # ── POST /api/people/seed ─────────────────────────────────────────
        if method == 'POST' and parts and parts[0] == 'seed':
            return respond(200, seed_demo_data())

        person_id = parts[0] if parts and parts[0] not in ('login', 'seed') else None

        # ── GET ───────────────────────────────────────────────────────────
        if method == 'GET':
            if person_id:
                rows = execute_query(
                    f"SELECT {PUBLIC_FIELDS} FROM people WHERE id = %s", (person_id,)
                )
                return respond(200, rows[0]) if rows else respond(404, {'message': 'Person not found'})

            conds, params = [], []
            if qp.get('role'):
                conds.append("role = %s")
                params.append(qp['role'])
            if qp.get('department'):
                conds.append("department = %s")
                params.append(qp['department'])
            if qp.get('search'):
                conds.append("(name ILIKE %s OR email ILIKE %s OR title ILIKE %s OR employee_id ILIKE %s)")
                s = f"%{qp['search']}%"
                params += [s, s, s, s]
            where = f"WHERE {' AND '.join(conds)}" if conds else ""
            rows = execute_query(
                f"SELECT {PUBLIC_FIELDS} FROM people {where} ORDER BY name ASC",
                params or None
            )
            return respond(200, rows)

        # ── POST create ───────────────────────────────────────────────────
        if method == 'POST':
            if not body.get('email') or not body.get('name'):
                return respond(400, {'message': 'Name and email are required'})
            password = body.get('password') or 'Welcome@123'
            emp_id = body.get('employee_id') or next_employee_id()
            rows = execute_query(f"""
                INSERT INTO people
                    (employee_id, name, email, password_hash, role, title, department,
                     capacity_hours, allocated_hours, projects, phone, location, bio, joined_date)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                RETURNING {PUBLIC_FIELDS}
            """, (
                emp_id,
                body.get('name'),
                body.get('email').strip().lower(),
                hash_password(password),
                body.get('role', 'member'),
                body.get('title', ''),
                body.get('department', ''),
                int(body.get('capacity_hours') or 40),
                int(body.get('allocated_hours') or 0),
                body.get('projects', ''),
                body.get('phone', ''),
                body.get('location', ''),
                body.get('bio', ''),
                body.get('joined_date') or None,
            ))
            return respond(201, rows[0] if rows else {})

        # ── PUT update ────────────────────────────────────────────────────
        if method == 'PUT' and person_id:
            fields = ['name', 'email', 'role', 'title', 'department', 'capacity_hours',
                      'allocated_hours', 'projects', 'phone', 'location', 'bio', 'joined_date']
            sets, params = [], []
            for f in fields:
                if f in body:
                    sets.append(f"{f} = %s")
                    val = body[f]
                    if f == 'joined_date' and val == '':
                        val = None
                    params.append(val)
            # Password change is handled separately so it always gets hashed.
            if body.get('password'):
                sets.append("password_hash = %s")
                params.append(hash_password(body['password']))
            if not sets:
                return respond(400, {'message': 'No fields to update'})
            sets.append("updated_at = CURRENT_TIMESTAMP")
            params.append(person_id)
            rows = execute_query(
                f"UPDATE people SET {', '.join(sets)} WHERE id = %s RETURNING {PUBLIC_FIELDS}",
                params
            )
            return respond(200, rows[0] if rows else {})

        # ── DELETE ────────────────────────────────────────────────────────
        if method == 'DELETE' and person_id:
            execute_query("DELETE FROM people WHERE id = %s", (person_id,))
            return respond(200, {'message': 'Person removed'})

        return respond(405, {'message': 'Method not allowed'})

    except Exception as e:
        return respond(500, {'message': str(e)})


def next_employee_id():
    rows = execute_query(
        "SELECT employee_id FROM people WHERE employee_id LIKE 'ACME-%' ORDER BY employee_id DESC LIMIT 1"
    )
    if not rows:
        return 'ACME-1001'
    try:
        return f"ACME-{int(rows[0]['employee_id'].split('-')[1]) + 1}"
    except Exception:
        return 'ACME-1001'


# ── Demo seed ─────────────────────────────────────────────────────────────
DEMO_PEOPLE = [
    # (emp_id, name, email, password, role, title, dept, capacity, phone, location, bio, joined)
    ('ACME-1001', 'Alice Fernandes', 'alice.admin@acme.com', 'Admin@123', 'admin',
     'Head of PMO', 'Operations', 40, '+91 98400 11001', 'Chennai, IN',
     'Oversees portfolio governance, budgets and resourcing across all departments.', '2021-03-15'),
    ('ACME-1002', 'Michael Rao', 'michael.rao@acme.com', 'Manager@123', 'manager',
     'Engineering Manager', 'Engineering', 40, '+91 98400 11002', 'Bengaluru, IN',
     'Leads platform engineering projects and delivery planning.', '2022-01-10'),
    ('ACME-1003', 'Priya Nair', 'priya.nair@acme.com', 'Manager@123', 'manager',
     'Product Delivery Manager', 'Product', 40, '+91 98400 11003', 'Chennai, IN',
     'Owns customer-facing product initiatives end to end.', '2022-07-04'),
    ('ACME-1004', 'Daniel Okafor', 'daniel.okafor@acme.com', 'Manager@123', 'manager',
     'Infrastructure Manager', 'IT Infrastructure', 40, '+91 98400 11004', 'Hyderabad, IN',
     'Responsible for cloud migration and internal platform reliability.', '2021-11-22'),
    ('ACME-1005', 'Sana Kapoor', 'sana.kapoor@acme.com', 'Member@123', 'member',
     'Senior Backend Engineer', 'Engineering', 40, '+91 98400 11005', 'Bengaluru, IN',
     'Builds APIs and data services; focuses on Java and Python backends.', '2023-02-13'),
    ('ACME-1006', 'Rahul Menon', 'rahul.menon@acme.com', 'Member@123', 'member',
     'Frontend Engineer', 'Engineering', 40, '+91 98400 11006', 'Chennai, IN',
     'React and design-system work across internal tools.', '2023-06-01'),
    ('ACME-1007', 'Grace Liu', 'grace.liu@acme.com', 'Member@123', 'member',
     'QA Engineer', 'Quality', 40, '+91 98400 11007', 'Pune, IN',
     'Test automation and release verification.', '2023-09-18'),
    ('ACME-1008', 'Omar Haddad', 'omar.haddad@acme.com', 'Member@123', 'member',
     'DevOps Engineer', 'IT Infrastructure', 40, '+91 98400 11008', 'Hyderabad, IN',
     'CI/CD pipelines, Terraform and AWS operations.', '2022-10-05'),
    ('ACME-1009', 'Lena Fischer', 'lena.fischer@acme.com', 'Member@123', 'member',
     'UX Designer', 'Product', 40, '+91 98400 11009', 'Chennai, IN',
     'Interaction design and usability research.', '2024-01-08'),
    ('ACME-1010', 'Arjun Pillai', 'arjun.pillai@acme.com', 'Member@123', 'member',
     'Data Analyst', 'Product', 40, '+91 98400 11010', 'Bengaluru, IN',
     'Reporting, dashboards and delivery metrics.', '2024-04-29'),
]


def seed_demo_data():
    """Insert demo people if they don't already exist. Safe to run repeatedly."""
    created, skipped = [], []
    for (emp, name, email, pwd, role, title, dept, cap, phone, loc, bio, joined) in DEMO_PEOPLE:
        existing = execute_query("SELECT id FROM people WHERE LOWER(email) = %s", (email.lower(),))
        if existing:
            skipped.append(email)
            continue
        execute_query("""
            INSERT INTO people
                (employee_id, name, email, password_hash, role, title, department,
                 capacity_hours, allocated_hours, projects, phone, location, bio, joined_date)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,0,'',%s,%s,%s,%s)
        """, (emp, name, email.lower(), hash_password(pwd), role, title, dept, cap,
              phone, loc, bio, joined))
        created.append(email)
    return {'created': created, 'skipped': skipped,
            'message': f'{len(created)} people created, {len(skipped)} already existed'}
