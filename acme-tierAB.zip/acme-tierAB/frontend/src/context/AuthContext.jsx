import { createContext, useContext, useState } from 'react'
import { peopleService } from '../services/peopleService'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const s = sessionStorage.getItem('acme_user')
      return s ? JSON.parse(s) : null
    } catch {
      return null
    }
  })

  // Authenticates against POST /api/people/login. The server verifies the
  // PBKDF2 hash and returns the user (never a password hash). `user.role`
  // mirrors system_role so the existing RBAC keeps working unchanged.
  const login = async (email, password) => {
    try {
      const data = await peopleService.login(email, password)
      if (data?.success && data.user) {
        sessionStorage.setItem('acme_user', JSON.stringify(data.user))
        setUser(data.user)
        return { success: true }
      }
      return { success: false, message: data?.message || 'Invalid email or password' }
    } catch (e) {
      const message =
        e?.response?.data?.message ||
        (e?.response?.status === 401 ? 'Invalid email or password' : null) ||
        'Could not reach the sign-in service. Is the backend running?'
      return { success: false, message }
    }
  }

  const logout = () => {
    sessionStorage.removeItem('acme_user')
    setUser(null)
  }

  // Refresh the cached user from the server (e.g. after a profile change).
  const refreshUser = async () => {
    if (!user?.id) return
    try {
      const fresh = await peopleService.getById(user.id)
      if (fresh?.id) {
        const merged = { ...fresh, role: fresh.system_role }
        sessionStorage.setItem('acme_user', JSON.stringify(merged))
        setUser(merged)
      }
    } catch {
      /* keep cached user on failure */
    }
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
