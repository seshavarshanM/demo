import { useState, useEffect, useCallback } from 'react'
import Box from '@mui/material/Box'
import Paper from '@mui/material/Paper'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import TextField from '@mui/material/TextField'
import Select from '@mui/material/Select'
import MenuItem from '@mui/material/MenuItem'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import Grid from '@mui/material/Grid'
import IconButton from '@mui/material/IconButton'
import Dialog from '@mui/material/Dialog'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogActions from '@mui/material/DialogActions'
import Snackbar from '@mui/material/Snackbar'
import Alert from '@mui/material/Alert'
import Avatar from '@mui/material/Avatar'
import LinearProgress from '@mui/material/LinearProgress'
import Chip from '@mui/material/Chip'
import Skeleton from '@mui/material/Skeleton'
import Tooltip from '@mui/material/Tooltip'
import InputAdornment from '@mui/material/InputAdornment'
import AddIcon from '@mui/icons-material/Add'
import EditIcon from '@mui/icons-material/Edit'
import DeleteIcon from '@mui/icons-material/Delete'
import SearchIcon from '@mui/icons-material/Search'
import EmailIcon from '@mui/icons-material/Email'
import WorkIcon from '@mui/icons-material/Work'
import BadgeIcon from '@mui/icons-material/Badge'
import { peopleService } from '../services/peopleService'
import { useAuth } from '../context/AuthContext'
import { can } from '../utils/permissions'

const EMPTY = {
  employee_id: '', name: '', email: '', system_role: 'member', title: '',
  department: '', capacity_hours: 40, allocated_hours: 0, projects: '', password: ''
}

const ROLE_STYLE = {
  admin:   { bg: '#EDE9FE', color: '#5B21B6' },
  manager: { bg: '#DBEAFE', color: '#1E40AF' },
  member:  { bg: '#DCFCE7', color: '#166534' },
}

function getInitials(name = '') {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
}
function getColor(name = '') {
  const colors = ['#1565C0','#7C3AED','#065F46','#9A3412','#1E40AF','#6B21A8']
  return colors[(name.charCodeAt(0) || 0) % colors.length]
}

export default function People() {
  const { user } = useAuth()
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [dialog, setDialog] = useState({ open: false, mode: 'create', data: EMPTY })
  const [delConfirm, setDelConfirm] = useState(null)
  const [saving, setSaving] = useState(false)
  const [snack, setSnack] = useState({ open: false, msg: '', sev: 'success' })
  const [touched, setTouched] = useState({})

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = {}
      if (search) params.search = search
      setItems(await peopleService.getAll(params))
    } catch (e) {
      setSnack({ open: true, msg: e.message, sev: 'error' })
    } finally {
      setLoading(false)
    }
  }, [search])

  useEffect(() => { load() }, [load])

  const openCreate = () => { setTouched({}); setDialog({ open: true, mode: 'create', data: EMPTY }) }
  const openEdit   = (r) => { setTouched({}); setDialog({ open: true, mode: 'edit', data: { ...r, password: '' } }) }
  const closeDialog = () => setDialog(d => ({ ...d, open: false }))

  const validate = (d) => {
    const errs = {}
    if (!d.name?.trim()) errs.name = 'Name is required'
    if (!d.title?.trim()) errs.title = 'Job title is required'
    if (!d.department?.trim()) errs.department = 'Department is required'
    if (!d.email?.trim()) errs.email = 'Email is required (used for login)'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) errs.email = 'Invalid email format'
    if (!['admin', 'manager', 'member'].includes(d.system_role)) errs.system_role = 'Pick a system role'
    if (d.capacity_hours === '' || Number(d.capacity_hours) < 1) errs.capacity_hours = 'Capacity must be at least 1 hour'
    if (Number(d.allocated_hours) < 0) errs.allocated_hours = 'Cannot be negative'
    if (dialog.mode === 'create' && d.password && d.password.length < 6) errs.password = 'Use at least 6 characters'
    if (dialog.mode === 'edit' && d.password && d.password.length < 6) errs.password = 'Use at least 6 characters'
    return errs
  }
  const errors = validate(dialog.data)
  const isValid = Object.keys(errors).length === 0
  const showErr = (field) => touched[field] && errors[field]

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = { ...dialog.data }
      if (!payload.password) delete payload.password  // don't overwrite/clear the hash
      if (dialog.mode === 'create') {
        await peopleService.create(payload)
        setSnack({ open: true, msg: 'Person added', sev: 'success' })
      } else {
        await peopleService.update(dialog.data.id, payload)
        setSnack({ open: true, msg: 'Person updated', sev: 'success' })
      }
      closeDialog()
      load()
    } catch (e) {
      setSnack({ open: true, msg: e.response?.data?.message || e.message, sev: 'error' })
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    try {
      await peopleService.remove(delConfirm.id)
      setSnack({ open: true, msg: 'Removed', sev: 'success' })
      setDelConfirm(null)
      load()
    } catch (e) {
      setSnack({ open: true, msg: e.message, sev: 'error' })
    }
  }

  const f = (field) => (e) => {
    setTouched(t => ({ ...t, [field]: true }))
    setDialog(d => ({ ...d, data: { ...d.data, [field]: e.target.value } }))
  }

  const overAllocated = items.filter(r => Number(r.allocated_hours) > Number(r.capacity_hours))

  return (
    <Box>
      <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>People</Typography>
          <Typography variant="body2" color="text.secondary">
            {items.length} people
            {overAllocated.length > 0 && (
              <Chip label={`${overAllocated.length} over-allocated`} size="small" color="error"
                sx={{ ml: 1.5, fontWeight: 600, fontSize: '0.72rem' }} />
            )}
          </Typography>
        </Box>
        {can(user, 'resource:create') && (
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}
            sx={{ borderRadius: 2, textTransform: 'none', fontWeight: 600 }}>
            Add Person
          </Button>
        )}
      </Box>

      <TextField
        size="small"
        placeholder="Search by name, title, email, ID…"
        value={search}
        onChange={e => setSearch(e.target.value)}
        InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
        sx={{ mb: 2, minWidth: 300 }}
      />

      <Grid container spacing={2}>
        {loading
          ? Array.from({ length: 6 }).map((_, i) => (
              <Grid item xs={12} sm={6} md={4} key={i}>
                <Paper elevation={0} sx={{ p: 2.5, borderRadius: 3, border: '1px solid', borderColor: 'divider' }}>
                  <Skeleton variant="circular" width={48} height={48} />
                  <Skeleton variant="text" width="60%" sx={{ mt: 1 }} />
                  <Skeleton variant="text" width="80%" />
                </Paper>
              </Grid>
            ))
          : items.length === 0
          ? (
              <Grid item xs={12}>
                <Paper elevation={0} sx={{ p: 5, borderRadius: 3, border: '1px solid', borderColor: 'divider', textAlign: 'center' }}>
                  <Typography color="text.secondary">No people yet. Add someone or run the seed.</Typography>
                </Paper>
              </Grid>
            )
          : items.map(r => {
              const allocPct = r.capacity_hours > 0
                ? Math.round((Number(r.allocated_hours) / Number(r.capacity_hours)) * 100)
                : 0
              const isOver = allocPct > 100
              const roleStyle = ROLE_STYLE[r.system_role] || ROLE_STYLE.member

              return (
                <Grid item xs={12} sm={6} md={4} key={r.id}>
                  <Paper
                    elevation={0}
                    sx={{
                      p: 2.5, borderRadius: 3,
                      border: '1px solid',
                      borderColor: isOver ? '#FCA5A5' : 'divider',
                      position: 'relative',
                    }}
                  >
                    <Box sx={{ position: 'absolute', top: 8, right: 8, display: 'flex' }}>
                      {can(user, 'resource:edit') && (
                        <Tooltip title="Edit"><IconButton size="small" onClick={() => openEdit(r)}><EditIcon fontSize="small" /></IconButton></Tooltip>
                      )}
                      {can(user, 'resource:delete') && (
                        <Tooltip title="Remove"><IconButton size="small" color="error" onClick={() => setDelConfirm(r)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
                      )}
                    </Box>

                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5, pr: 8 }}>
                      <Avatar sx={{ bgcolor: getColor(r.name), width: 44, height: 44, fontWeight: 700 }}>
                        {getInitials(r.name)}
                      </Avatar>
                      <Box sx={{ minWidth: 0 }}>
                        <Typography fontWeight={700} fontSize="0.95rem" noWrap>{r.name}</Typography>
                        <Typography variant="caption" color="text.secondary">{r.title || 'No title set'}</Typography>
                      </Box>
                    </Box>

                    <Box sx={{ display: 'flex', gap: 0.5, mb: 1.5, flexWrap: 'wrap', alignItems: 'center' }}>
                      <Chip label={(r.system_role || 'member').toUpperCase()} size="small"
                        sx={{ fontWeight: 700, fontSize: '0.66rem', height: 22, bgcolor: roleStyle.bg, color: roleStyle.color }} />
                      <Chip icon={<BadgeIcon />} label={r.employee_id} size="small"
                        sx={{ fontSize: '0.7rem', height: 22 }} />
                      {r.department && (
                        <Chip icon={<WorkIcon />} label={r.department} size="small"
                          sx={{ fontSize: '0.7rem', height: 22 }} />
                      )}
                    </Box>

                    {r.email && (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mb: 1.5 }}>
                        <EmailIcon sx={{ fontSize: 14, color: 'text.secondary' }} />
                        <Typography variant="caption" color="text.secondary" noWrap>{r.email}</Typography>
                      </Box>
                    )}

                    <Box sx={{ display: 'flex', gap: 0.5, mb: 1.5, flexWrap: 'wrap', alignItems: 'center' }}>
                      {isOver ? (
                        <Chip label="Over-allocated" size="small"
                          sx={{ fontWeight: 700, fontSize: '0.68rem', bgcolor: '#FEE2E2', color: '#991B1B' }} />
                      ) : allocPct < 50 ? (
                        <Chip label="Available" size="small"
                          sx={{ fontWeight: 700, fontSize: '0.68rem', bgcolor: '#DCFCE7', color: '#166534' }} />
                      ) : null}
                      {(r.projects || '').split(',').map(s => s.trim()).filter(Boolean).map((p, i) => (
                        <Chip key={i} label={p.replace(/\s*\(\d+h\)/, '')} size="small" variant="outlined"
                          sx={{ fontSize: '0.68rem', height: 22 }} />
                      ))}
                    </Box>

                    <Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5, gap: 1, flexWrap: 'wrap' }}>
                        <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>Allocation</Typography>
                        <Typography variant="caption" fontWeight={700} sx={{ whiteSpace: 'nowrap' }} color={isOver ? 'error.main' : 'text.primary'}>
                          {r.allocated_hours}h / {r.capacity_hours}h · {allocPct}%
                        </Typography>
                      </Box>
                      <LinearProgress
                        variant="determinate"
                        value={Math.min(allocPct, 100)}
                        sx={{
                          height: 6, borderRadius: 3, bgcolor: '#E2E8F0',
                          '& .MuiLinearProgress-bar': {
                            bgcolor: isOver ? '#DC2626' : allocPct > 75 ? '#D97706' : '#16A34A',
                            borderRadius: 3
                          }
                        }}
                      />
                    </Box>
                  </Paper>
                </Grid>
              )
            })
        }
      </Grid>

      {/* Dialog */}
      <Dialog open={dialog.open} onClose={closeDialog} maxWidth="sm" fullWidth>
        <DialogTitle fontWeight={700}>{dialog.mode === 'create' ? 'Add Person' : 'Edit Person'}</DialogTitle>
        <DialogContent dividers>
          <Grid container spacing={2} sx={{ pt: 0.5 }}>
            <Grid item xs={12} sm={6}><TextField fullWidth label="Full name *" value={dialog.data.name} onChange={f('name')}
              error={!!showErr('name')} helperText={showErr('name') || ''} /></Grid>
            <Grid item xs={12} sm={6}><TextField fullWidth label="Employee ID" value={dialog.data.employee_id} onChange={f('employee_id')}
              helperText="Leave blank to auto-assign (ACME-00NN)" /></Grid>
            <Grid item xs={12} sm={6}><TextField fullWidth type="email" label="Email *" value={dialog.data.email} onChange={f('email')}
              error={!!showErr('email')} helperText={showErr('email') || 'Used to sign in'} /></Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth error={!!showErr('system_role')}>
                <InputLabel>System role *</InputLabel>
                <Select label="System role *" value={dialog.data.system_role} onChange={f('system_role')}>
                  {['admin', 'manager', 'member'].map(s => (
                    <MenuItem key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}><TextField fullWidth label="Job title *" value={dialog.data.title} onChange={f('title')}
              error={!!showErr('title')} helperText={showErr('title') || ''} /></Grid>
            <Grid item xs={12} sm={6}><TextField fullWidth label="Department *" value={dialog.data.department} onChange={f('department')}
              error={!!showErr('department')} helperText={showErr('department') || ''} /></Grid>
            <Grid item xs={12} sm={6}><TextField fullWidth type="number" label="Capacity (hrs/week) *" value={dialog.data.capacity_hours} onChange={f('capacity_hours')} inputProps={{ min: 1 }}
              error={!!showErr('capacity_hours')} helperText={showErr('capacity_hours') || ''} /></Grid>
            <Grid item xs={12} sm={6}><TextField fullWidth type="number" label="Allocated (hrs/week)" value={dialog.data.allocated_hours} onChange={f('allocated_hours')} inputProps={{ min: 0 }}
              error={!!showErr('allocated_hours')} helperText={showErr('allocated_hours') || ''} /></Grid>
            <Grid item xs={12}><TextField fullWidth type="password" autoComplete="new-password"
              label={dialog.mode === 'create' ? 'Initial password' : 'Reset password'}
              value={dialog.data.password} onChange={f('password')}
              error={!!showErr('password')}
              helperText={showErr('password') || (dialog.mode === 'create'
                ? 'Optional — defaults to ChangeMe@ACME if left blank'
                : 'Leave blank to keep the current password')} /></Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={closeDialog} sx={{ textTransform: 'none' }}>Cancel</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving || !isValid}
            sx={{ textTransform: 'none', fontWeight: 600 }}>
            {saving ? 'Saving…' : dialog.mode === 'create' ? 'Add' : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete confirm */}
      <Dialog open={!!delConfirm} onClose={() => setDelConfirm(null)} maxWidth="xs" fullWidth>
        <DialogTitle fontWeight={700}>Remove person?</DialogTitle>
        <DialogContent><Typography>"{delConfirm?.name}" ({delConfirm?.employee_id}) will be removed and can no longer sign in.</Typography></DialogContent>
        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={() => setDelConfirm(null)} sx={{ textTransform: 'none' }}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDelete} sx={{ textTransform: 'none' }}>Remove</Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={snack.open} autoHideDuration={3500} onClose={() => setSnack(s => ({ ...s, open: false }))} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert severity={snack.sev} variant="filled" sx={{ borderRadius: 2 }}>{snack.msg}</Alert>
      </Snackbar>
    </Box>
  )
}
