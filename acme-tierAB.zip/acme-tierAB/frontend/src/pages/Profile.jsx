import { useState, useEffect } from 'react'
import Box from '@mui/material/Box'
import Paper from '@mui/material/Paper'
import Typography from '@mui/material/Typography'
import Grid from '@mui/material/Grid'
import Avatar from '@mui/material/Avatar'
import Chip from '@mui/material/Chip'
import Divider from '@mui/material/Divider'
import LinearProgress from '@mui/material/LinearProgress'
import Skeleton from '@mui/material/Skeleton'
import Alert from '@mui/material/Alert'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import BadgeIcon from '@mui/icons-material/Badge'
import EmailIcon from '@mui/icons-material/Email'
import { peopleService } from '../services/peopleService'
import { projectService } from '../services/projectService'
import { deliverableService } from '../services/deliverableService'
import { useAuth } from '../context/AuthContext'
import StatusChip from '../components/StatusChip'

const ROLE_STYLE = {
  admin:   { bg: '#EDE9FE', color: '#5B21B6' },
  manager: { bg: '#DBEAFE', color: '#1E40AF' },
  member:  { bg: '#DCFCE7', color: '#166534' },
}

function getInitials(name = '') {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
}
function getColor(name = '') {
  const colors = ['#1565C0', '#7C3AED', '#065F46', '#9A3412', '#1E40AF', '#6B21A8']
  return colors[(name.charCodeAt(0) || 0) % colors.length]
}
// Parse the "Project (Xh)" allocation CSV into { name, hours } entries.
function parseAllocations(csv) {
  return (csv || '').split(',').map(s => s.trim()).filter(Boolean).map(e => {
    const m = e.match(/^(.*?)\s*\((\d+)h\)$/)
    return m ? { name: m[1], hours: Number(m[2]) } : { name: e, hours: null }
  })
}

function InfoItem({ label, value }) {
  return (
    <Box sx={{ minWidth: 120 }}>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.25 }}>
        {label}
      </Typography>
      <Typography variant="body2" fontWeight={600}>{value ?? '—'}</Typography>
    </Box>
  )
}

export default function Profile() {
  const { user } = useAuth()
  const [person, setPerson] = useState(null)
  const [deliverables, setDeliverables] = useState([])
  const [managed, setManaged] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!user?.id) return
    setLoading(true)
    Promise.all([
      peopleService.getById(user.id),
      deliverableService.getAll({ assigned_to: user.name }),
      projectService.getAll(),
    ])
      .then(([p, d, projs]) => {
        setPerson(p)
        setDeliverables(d)
        setManaged((projs || []).filter(pr => pr.manager === user.name))
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [user])

  if (loading) {
    return (
      <Box>
        <Skeleton variant="text" width={220} height={40} />
        <Skeleton variant="rectangular" height={180} sx={{ mt: 2, borderRadius: 3 }} />
      </Box>
    )
  }
  if (error) return <Alert severity="error">{error}</Alert>
  if (!person) return <Alert severity="warning">Profile not available.</Alert>

  const roleStyle = ROLE_STYLE[person.system_role] || ROLE_STYLE.member
  const capacity = Number(person.capacity_hours || 0)
  const allocated = Number(person.allocated_hours || 0)
  const util = capacity > 0 ? Math.round((allocated / capacity) * 100) : 0
  const teamProjects = parseAllocations(person.projects)
  const managedNames = new Set(managed.map(p => p.name))
  const doneCount = deliverables.filter(d => d.status === 'completed').length

  return (
    <Box>
      <Typography variant="h5" fontWeight={700} sx={{ mb: 0.5 }}>My Profile</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Your identity, capacity, and current work
      </Typography>

      {/* Identity card */}
      <Paper elevation={0} sx={{ borderRadius: 3, border: '1px solid', borderColor: 'divider', mb: 2, overflow: 'hidden' }}>
        <Box sx={{ height: 6, background: 'linear-gradient(90deg,#1565C0,#7C3AED)' }} />
        <Box sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
            <Avatar sx={{ width: 64, height: 64, fontSize: '1.4rem', fontWeight: 700, bgcolor: getColor(person.name) }}>
              {getInitials(person.name)}
            </Avatar>
            <Box sx={{ flex: 1, minWidth: 200 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
                <Typography variant="h6" fontWeight={800}>{person.name}</Typography>
                <Chip label={(person.system_role || 'member').toUpperCase()} size="small"
                  sx={{ fontWeight: 700, fontSize: '0.68rem', bgcolor: roleStyle.bg, color: roleStyle.color }} />
              </Box>
              <Typography variant="body2" color="text.secondary">{person.title || '—'}</Typography>
              <Box sx={{ display: 'flex', gap: 2, mt: 0.75, flexWrap: 'wrap' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <BadgeIcon sx={{ fontSize: 15, color: 'text.secondary' }} />
                  <Typography variant="caption" color="text.secondary" fontWeight={600}>{person.employee_id}</Typography>
                </Box>
                {person.email && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <EmailIcon sx={{ fontSize: 15, color: 'text.secondary' }} />
                    <Typography variant="caption" color="text.secondary">{person.email}</Typography>
                  </Box>
                )}
              </Box>
            </Box>
          </Box>

          <Divider sx={{ my: 2.5 }} />

          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 4, mb: 2.5 }}>
            <InfoItem label="Employee ID" value={person.employee_id} />
            <InfoItem label="System role" value={(person.system_role || 'member').replace(/\b\w/, c => c.toUpperCase())} />
            <InfoItem label="Department" value={person.department} />
            <InfoItem label="Capacity" value={`${capacity}h / week`} />
          </Box>

          <Box sx={{ maxWidth: 420 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
              <Typography variant="caption" color="text.secondary">Allocation</Typography>
              <Typography variant="caption" fontWeight={700} color={util > 100 ? 'error.main' : 'text.primary'}>
                {allocated}h / {capacity}h · {util}%
              </Typography>
            </Box>
            <LinearProgress variant="determinate" value={Math.min(util, 100)}
              sx={{ height: 8, borderRadius: 4, bgcolor: '#E2E8F0',
                '& .MuiLinearProgress-bar': {
                  bgcolor: util > 100 ? '#DC2626' : util > 75 ? '#D97706' : '#16A34A', borderRadius: 4 } }} />
          </Box>
        </Box>
      </Paper>

      {/* Projects I'm on */}
      <Paper elevation={0} sx={{ borderRadius: 3, border: '1px solid', borderColor: 'divider', mb: 2 }}>
        <Box sx={{ px: 3, py: 2 }}>
          <Typography fontWeight={700}>
            My Projects ({teamProjects.length + managed.filter(p => !teamProjects.some(t => t.name === p.name)).length})
          </Typography>
        </Box>
        <Divider />
        {teamProjects.length === 0 && managed.length === 0 ? (
          <Box sx={{ py: 4, textAlign: 'center' }}>
            <Typography color="text.secondary" variant="body2">You're not assigned to any projects yet.</Typography>
          </Box>
        ) : (
          <Box sx={{ p: 2, display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
            {/* Managed projects first */}
            {managed.map(p => (
              <Paper key={`m-${p.id}`} elevation={0} sx={{
                px: 2, py: 1.25, borderRadius: 2, border: '1px solid', borderColor: 'divider', bgcolor: '#FAFBFC',
                display: 'flex', alignItems: 'center', gap: 1.25 }}>
                <Typography fontSize="0.85rem" fontWeight={600}>{p.name}</Typography>
                <Chip size="small" label="Manager"
                  sx={{ fontWeight: 700, fontSize: '0.68rem', bgcolor: '#DBEAFE', color: '#1E40AF' }} />
              </Paper>
            ))}
            {/* Team memberships (skip ones already shown as managed) */}
            {teamProjects.filter(t => !managedNames.has(t.name)).map((t, i) => (
              <Paper key={`t-${i}`} elevation={0} sx={{
                px: 2, py: 1.25, borderRadius: 2, border: '1px solid', borderColor: 'divider', bgcolor: '#FAFBFC',
                display: 'flex', alignItems: 'center', gap: 1.25 }}>
                <Typography fontSize="0.85rem" fontWeight={600}>{t.name}</Typography>
                {t.hours != null && (
                  <Chip size="small" label={`${t.hours}h/wk`}
                    sx={{ fontWeight: 700, fontSize: '0.68rem', bgcolor: '#DCFCE7', color: '#166534' }} />
                )}
              </Paper>
            ))}
          </Box>
        )}
      </Paper>

      {/* My deliverables */}
      <Paper elevation={0} sx={{ borderRadius: 3, border: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ px: 3, py: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography fontWeight={700}>My Deliverables ({deliverables.length})</Typography>
          <Typography variant="caption" color="text.secondary">{doneCount} completed</Typography>
        </Box>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ '& th': { fontWeight: 700, fontSize: '0.78rem', bgcolor: '#F8FAFC' } }}>
                <TableCell>Deliverable</TableCell>
                <TableCell>Project</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Due Date</TableCell>
                <TableCell>Progress</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {deliverables.length === 0
                ? <TableRow><TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                    Nothing assigned to you right now.
                  </TableCell></TableRow>
                : deliverables.map(d => (
                    <TableRow key={d.id} hover>
                      <TableCell><Typography fontWeight={600} fontSize="0.85rem">{d.name}</Typography></TableCell>
                      <TableCell sx={{ fontSize: '0.82rem', color: 'text.secondary' }}>{d.project_name || '—'}</TableCell>
                      <TableCell><StatusChip value={d.status} /></TableCell>
                      <TableCell sx={{ fontSize: '0.82rem', color: 'text.secondary' }}>
                        {d.due_date ? new Date(d.due_date).toLocaleDateString() : '—'}
                      </TableCell>
                      <TableCell sx={{ minWidth: 110 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <LinearProgress variant="determinate" value={d.completion_percentage || 0}
                            sx={{ flex: 1, height: 6, borderRadius: 3, bgcolor: '#E2E8F0',
                              '& .MuiLinearProgress-bar': { bgcolor: '#1565C0', borderRadius: 3 } }} />
                          <Typography variant="caption">{d.completion_percentage || 0}%</Typography>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
    </Box>
  )
}
