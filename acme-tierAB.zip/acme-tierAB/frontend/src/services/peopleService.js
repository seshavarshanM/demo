import api from './api'

// The `people` table replaces `resources`: one row = one human, used for
// login, allocation/assignment, and as the assignee list.
const BASE = '/people'

function ensureArray(data, label) {
  if (!Array.isArray(data)) {
    console.error(`[peopleService] Expected array from ${label}, got:`, data)
    return []
  }
  return data
}

export const peopleService = {
  getAll: (params = {}) =>
    api.get(BASE, { params }).then(r => ensureArray(r.data, 'GET /people')),
  getById: (id) => api.get(`${BASE}/${id}`).then(r => r.data),
  create:  (data) => api.post(BASE, data).then(r => r.data),
  update:  (id, data) => api.put(`${BASE}/${id}`, data).then(r => r.data),
  remove:  (id) => api.delete(`${BASE}/${id}`).then(r => r.data),

  // Auth — real accounts, verified server-side against PBKDF2 hashes.
  login: (email, password) =>
    api.post(`${BASE}/login`, { email, password }).then(r => r.data),

  // One-shot workshop seed (wipes + reloads people/projects/deliverables/budget).
  seed: () => api.post(`${BASE}/seed`).then(r => r.data),
}

// Back-compat alias so any lingering imports keep working.
export const resourceService = peopleService
