# ACME workshop — Tier A + Tier B batch

Drop-in replacement files for the ACME PM app. Tier A (data integrity) and
Tier B (identity) are implemented, plus seed data and the credentials sheet.
The FAANG-style UI restyle + Deliverables card redesign (Tier C) is deferred
to a later batch, as requested.

> **One conflict, resolved:** the one-line ask said *bcrypt*, the detailed
> brief said *PBKDF2 via `hashlib`, no new dependencies*. Those contradict —
> bcrypt needs a third-party package. I followed the brief: **PBKDF2-HMAC-
> SHA256** (200k iterations, per-user salt, stdlib only). Stored format
> `pbkdf2_sha256$iterations$salt$hash`. If you truly want bcrypt, say so and
> I'll swap it (adds a dependency to vendor into the Lambda).

> **Login path:** the brief said `/api/auth/login`, but your Terraform routes
> by folder (first path segment → service). A folder named `people` owns
> `/api/people/*`, so login lives at **`POST /api/people/login`**. Same
> service, guaranteed routing. (An `auth` folder would need its own copy of
> the DB layer + vendored driver.)

---

## 1) Backend — copy in

The new `people` service reuses the exact driver setup your other services
already have. Easiest is to clone `resources`, then drop in the new code:

```sh
cd <repo>/backend

# 1. create the people service WITH the vendored psycopg driver (reuse resources')
cp -r resources people

# 2. overwrite with the new code (from this package's backend/people/)
cp -f <pkg>/backend/people/function.py         people/function.py
cp -f <pkg>/backend/people/seed_data.py        people/seed_data.py
cp -f <pkg>/backend/people/postgres_service.py people/postgres_service.py
cp -f <pkg>/backend/people/requirements.txt    people/requirements.txt

# 3. retire the old resources service so it stops deploying
rm -rf resources

# 4. replace the three changed services
cp -f <pkg>/backend/projects/function.py      projects/function.py
cp -f <pkg>/backend/deliverables/function.py  deliverables/function.py
cp -f <pkg>/backend/budget/function.py        budget/function.py
```

If you'd rather not clone `resources`, just vendor the driver the same way you
did originally: `cd people && pip install -r requirements.txt -t .`

## 2) Frontend — copy in

```sh
cd <repo>/frontend

# new files
cp -f <pkg>/frontend/src/pages/People.jsx        src/pages/People.jsx
cp -f <pkg>/frontend/src/pages/Profile.jsx       src/pages/Profile.jsx
cp -f <pkg>/frontend/src/services/peopleService.js src/services/peopleService.js

# changed files
cp -f <pkg>/frontend/src/App.jsx                 src/App.jsx
cp -f <pkg>/frontend/src/context/AuthContext.jsx src/context/AuthContext.jsx
cp -f <pkg>/frontend/src/components/Sidebar.jsx  src/components/Sidebar.jsx
cp -f <pkg>/frontend/src/pages/Login.jsx         src/pages/Login.jsx
cp -f <pkg>/frontend/src/pages/Projects.jsx      src/pages/Projects.jsx
cp -f <pkg>/frontend/src/pages/Deliverables.jsx  src/pages/Deliverables.jsx
cp -f <pkg>/frontend/src/pages/ProjectDetail.jsx src/pages/ProjectDetail.jsx
cp -f <pkg>/frontend/src/pages/Budget.jsx        src/pages/Budget.jsx
cp -f <pkg>/frontend/src/pages/Dashboard.jsx     src/pages/Dashboard.jsx

# remove the superseded files
rm -f src/pages/Resources.jsx src/services/resourceService.js
```

## 3) Run + seed

```sh
./bin/start-dev.sh
# once the stack is up, load the seed (people + projects + deliverables + budget):
curl -X POST http://localhost:3001/api/people/seed
```

Then sign in with any account on the credentials sheet
(`ACME-seed-credentials.pdf`). Re-running the seed wipes and reloads those four
tables (TRUNCATE), so it's safe to run repeatedly. For AWS, deploy then
`curl -X POST https://<API_BASE_URL>/api/people/seed` once.

---

## What changed

### Tier B — identity
- **`people` table replaces `resources`.** Columns: `employee_id` (unique,
  `ACME-00NN`), `name`, `email` (unique), `password_hash`, `system_role`
  (admin/manager/member), `title` (job title), `department`, `capacity_hours`,
  `allocated_hours`, `projects`. One row = one human: login + allocation +
  assignee list.
- **Real login.** `POST /api/people/login` verifies the PBKDF2 hash server-side
  and returns the user (never the hash). `user.role` mirrors `system_role`, so
  your existing RBAC (`utils/permissions.js`) works unchanged. The 3 hardcoded
  demo users are gone.
- **Profile page** (new sidebar item) — the signed-in person's ID, system role,
  department, capacity/utilization, the projects they're on (managed + team),
  and their deliverables.
- **Real-people dropdowns.** Project *Manager* and deliverable *Assignee* are now
  `<Select>`s of actual people (no more "Mike Manager" vs "Mike Manger"). Values
  are still stored as names, so the manager/assignee matching in the dashboards
  keeps working.
- **People directory** (`/people`, was `/resources`) shows employee ID, title,
  system-role chip, email, allocation. Admins can add/edit people (optional
  password on create → hashed; blank reset on edit keeps the current password).

### Tier A — data integrity
- **Derived project completion.** `projects` GET returns completion as the
  rounded AVG of that project's deliverables; the manual field is removed from
  the form (edit shows it read-only as "…% (auto)") and the API no longer
  accepts a manual value. No deliverables ⇒ 0%.
- **Deliverable status ↔ completion** are locked together **server-side** (so it
  holds no matter who calls) and mirrored in the form for instant feedback:
  Completed ⇒ 100%; 100% ⇒ Completed; a partial % on a Completed item reopens it
  to In Progress. Invariant: `completed ⇔ 100%`.
- **Budget ceiling validation.** `GET /api/budget?project_id=…` now returns
  `summary.ceiling` / `over_ceiling` / `ceiling_remaining`. The Budget page shows
  a scoped banner, the entry dialog warns live if this entry would push the
  project's planned total over its ceiling, and ProjectDetail flags it too. It's
  a clear warning, not a hard block. Header spend is still summed from entries.

### Seed data
1 admin, 3 managers, 6 members · 5 projects · 14 deliverables with dependency
chains (`depends_on`) · 12 budget entries (all within ceilings) · team
allocations wired into each member's capacity. All passwords stored only as
PBKDF2 hashes.

## Verified in-container
- Backend: 47 unit checks green (PBKDF2 hash/verify + constant-time compare;
  status↔completion normalizer incl. edge cases; seed-data integrity; full
  seed orchestration against an in-memory DB confirming hashes-not-plaintext,
  dependency resolution, and allocations; login handler returns no hash and
  401s on bad password).
- Frontend: `vite build` passes clean; no dangling `resources`/`resourceService`
  references.
- Credentials PDF rendered and visually verified.

## Not in this batch (deferred Tier C)
FAANG-style restyle (typography scale, shadows, color system, empty states) and
the grouped-card Deliverables redesign.
