import json
from postgres_service import execute_query

HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
}


def respond(status, body):
    return {'statusCode': status, 'headers': HEADERS, 'body': json.dumps(body, default=str)}


def get_method(event):
    return (
        event.get('httpMethod')
        or (event.get('requestContext') or {}).get('http', {}).get('method')
        or 'GET'
    ).upper()


def get_path(event):
    return event.get('path') or event.get('rawPath') or ''


def get_id(event):
    pp = event.get('pathParameters') or {}
    if pp.get('id'):
        return pp['id']
    path = get_path(event)
    parts = [p for p in path.split('/') if p and p not in ('api', 'deliverables')]
    return parts[-1] if parts else None


def _to_int(v, default=0):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def normalize_status_pct(prev_status, prev_pct, in_status, in_pct):
    """Tier A: keep deliverable status and completion in lock-step.

    Rules (authoritative on the server, regardless of caller):
      - choosing 'completed'         -> completion snaps to 100
      - completion reaches 100       -> status becomes 'completed'
      - a partial % on a 'completed' item -> reopen to 'in_progress'
    Invariant: status == 'completed'  <=>  completion == 100.
    in_status / in_pct are None when the caller did not send that field.
    """
    status = in_status if in_status is not None else prev_status
    pct = _to_int(in_pct if in_pct is not None else prev_pct, _to_int(prev_pct))
    pct = max(0, min(100, pct))

    status_set = in_status is not None and in_status != prev_status
    pct_set = in_pct is not None and _to_int(in_pct) != _to_int(prev_pct)

    if status_set and status == 'completed':
        pct = 100
    elif pct_set and pct == 100:
        status = 'completed'
    elif pct_set and pct < 100 and status == 'completed':
        status = 'in_progress'
    elif status_set and status != 'completed' and pct == 100:
        # deliberately moved off 'completed' but left at 100% — nudge below full
        pct = 99

    if status == 'completed':
        pct = 100
    return status, max(0, min(100, pct))


def init_db():
    execute_query("""
        CREATE TABLE IF NOT EXISTS deliverables (
            id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            project_id            UUID,
            project_name          VARCHAR(255) DEFAULT '',
            name                  VARCHAR(255) NOT NULL,
            description           TEXT         DEFAULT '',
            status                VARCHAR(50)  DEFAULT 'pending',
            due_date              DATE,
            assigned_to           VARCHAR(255) DEFAULT '',
            depends_on            UUID,
            completion_percentage INTEGER      DEFAULT 0,
            created_at            TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
            updated_at            TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
        )
    """)


def handler(event, context):
    try:
        init_db()
        method = get_method(event)
        item_id = get_id(event)
        qp = event.get('queryStringParameters') or {}
        body = json.loads(event['body']) if event.get('body') else {}

        if method == 'OPTIONS':
            return respond(200, {})

        if method == 'GET':
            if item_id:
                rows = execute_query("SELECT * FROM deliverables WHERE id = %s", (item_id,))
                return respond(200, rows[0]) if rows else respond(404, {'message': 'Not found'})

            conds, params = [], []
            if qp.get('project_id'):
                conds.append("project_id = %s::uuid")
                params.append(qp['project_id'])
            if qp.get('status'):
                conds.append("status = %s")
                params.append(qp['status'])
            if qp.get('assigned_to'):
                conds.append("assigned_to = %s")
                params.append(qp['assigned_to'])
            if qp.get('search'):
                conds.append("(name ILIKE %s OR description ILIKE %s)")
                params += [f"%{qp['search']}%", f"%{qp['search']}%"]
            where = f"WHERE {' AND '.join(conds)}" if conds else ""
            rows = execute_query(
                f"SELECT * FROM deliverables {where} ORDER BY due_date ASC NULLS LAST",
                params or None
            )
            return respond(200, rows)

        if method == 'POST':
            status, pct = normalize_status_pct(
                'pending', 0,
                body.get('status', 'pending'),
                body.get('completion_percentage'),
            )
            rows = execute_query("""
                INSERT INTO deliverables
                    (project_id, project_name, name, description, status,
                     due_date, assigned_to, depends_on, completion_percentage)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                RETURNING *
            """, (
                body.get('project_id') or None,
                body.get('project_name', ''),
                body.get('name', 'Untitled Deliverable'),
                body.get('description', ''),
                status,
                body.get('due_date') or None,
                body.get('assigned_to', ''),
                body.get('depends_on') or None,
                pct,
            ))
            return respond(201, rows[0] if rows else {})

        if method == 'PUT' and item_id:
            prev = execute_query("SELECT * FROM deliverables WHERE id = %s", (item_id,))
            if not prev:
                return respond(404, {'message': 'Not found'})
            prev = prev[0]

            fields = [
                'project_id', 'project_name', 'name', 'description',
                'due_date', 'assigned_to', 'depends_on'
            ]
            sets, params = [], []
            for f in fields:
                if f in body:
                    val = body[f]
                    if val == '' and f in ('due_date', 'project_id', 'depends_on'):
                        val = None
                    sets.append(f"{f} = %s")
                    params.append(val)

            # status + completion move together, normalized against the prior row.
            if 'status' in body or 'completion_percentage' in body:
                status, pct = normalize_status_pct(
                    prev.get('status', 'pending'),
                    prev.get('completion_percentage', 0),
                    body.get('status') if 'status' in body else None,
                    body.get('completion_percentage') if 'completion_percentage' in body else None,
                )
                sets.append("status = %s")
                params.append(status)
                sets.append("completion_percentage = %s")
                params.append(pct)

            if not sets:
                return respond(200, prev)

            sets.append("updated_at = CURRENT_TIMESTAMP")
            params.append(item_id)
            rows = execute_query(
                f"UPDATE deliverables SET {', '.join(sets)} WHERE id = %s RETURNING *",
                params
            )
            return respond(200, rows[0] if rows else {})

        if method == 'DELETE' and item_id:
            execute_query("DELETE FROM deliverables WHERE id = %s", (item_id,))
            return respond(200, {'message': 'Deliverable deleted'})

        return respond(405, {'message': 'Method not allowed'})

    except Exception as e:
        return respond(500, {'message': str(e)})