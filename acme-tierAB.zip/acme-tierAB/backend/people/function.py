"""
People service — unified identity + allocation table.

Replaces the old `resources` service. One row = one human, used for login
(real accounts), for allocation/assignment, and as the assignee list.

Routes (folder-based discovery gives this service everything under /api/people):
    OPTIONS /api/people[...]        -> CORS preflight
    POST    /api/people/login       -> authenticate {email,password} -> user (no hash)
    POST    /api/people/seed        -> wipe + load the workshop seed data
    GET     /api/people             -> list people (never returns password_hash)
    GET     /api/people/{id}        -> one person
    POST    /api/people             -> create person (password optional -> hashed)
    PUT     /api/people/{id}        -> update person (password optional -> re-hashed)
    DELETE  /api/people/{id}        -> delete person

Passwords are hashed with PBKDF2-HMAC-SHA256 via the standard library
`hashlib` (no third-party crypto dependency). Stored format:
    pbkdf2_sha256$<iterations>$<salt_hex>$<hash_hex>
"""
import json
import hashlib
import hmac
import secrets
import re

from postgres_service import execute_query
import seed_data

HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
}

# Columns safe to return over the API (password_hash is deliberately excluded).
PUBLIC_COLS = (
    "id, employee_id, name, email, system_role, title, department, "
    "capacity_hours, allocated_hours, projects, created_at, updated_at"
)

VALID_ROLES = ('admin', 'manager', 'member')
UUID_RE = re.compile(r'^[0-9a-fA-F-]{32,36}$')

# ── Password hashing (PBKDF2-HMAC-SHA256, stdlib only) ───────────────────────
PBKDF2_ALGO = 'sha256'
PBKDF2_ITERATIONS = 200_000


def hash_password(password):
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac(PBKDF2_ALGO, (password or '').encode('utf-8'), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_{PBKDF2_ALGO}${PBKDF2_ITERATIONS}${salt.hex()}${dk.hex()}"


def verify_password(password, stored):
    try:
        algo_tag, iters, salt_hex, hash_hex = stored.split('$')
        algo = algo_tag.split('_', 1)[1]
        dk = hashlib.pbkdf2_hmac(algo, (password or '').encode('utf-8'),
                                 bytes.fromhex(salt_hex), int(iters))
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


# ── HTTP helpers ─────────────────────────────────────────────────────────────
def respond(status, body):
    return {'statusCode': status, 'headers': HEADERS, 'body': json.dumps(body, default=str)}


def get_method(event):
    return (
        event.get('httpMethod')
        or (event.get('requestContext') or {}).get('http', {}).get('method')
        or 'GET'
    ).upper()


def get_path(event):
    return event.get('path') or event.get('rawPath') or ''


def path_tail(event):
    """Last meaningful path segment after /api/people (or None)."""
    pp = event.get('pathParameters') or {}
    if pp.get('id'):
        return pp['id']
    path = get_path(event)
    parts = [p for p in path.split('/') if p and p not in ('api', 'people')]
    return parts[-1] if parts else None


# ── Schema ───────────────────────────────────────────────────────────────────
def init_db():
    execute_query("""
        CREATE TABLE IF NOT EXISTS people (
            id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            employee_id      VARCHAR(20)  UNIQUE NOT NULL,
            name             VARCHAR(255) NOT NULL,
            email            VARCHAR(255) UNIQUE NOT NULL,
            password_hash    TEXT         NOT NULL DEFAULT '',
            system_role      VARCHAR(20)  DEFAULT 'member',
            title            VARCHAR(255) DEFAULT '',
            department       VARCHAR(255) DEFAULT '',
            capacity_hours   INTEGER      DEFAULT 40,
            allocated_hours  INTEGER      DEFAULT 0,
            projects         TEXT         DEFAULT '',
            created_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
            updated_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
        )
    """)


def next_employee_id():
    rows = execute_query(
        "SELECT employee_id FROM people WHERE employee_id ~ '^ACME-[0-9]+$'"
    )
    mx = 0
    for r in rows:
        try:
            mx = max(mx, int(str(r['employee_id']).split('-')[1]))
        except Exception:
            pass
    return f"ACME-{mx + 1:04d}"


# ── Auth ─────────────────────────────────────────────────────────────────────
def do_login(body):
    email = (body.get('email') or '').strip().lower()
    password = body.get('password') or ''
    if not email or not password:
        return respond(400, {'message': 'Email and password are required'})

    rows = execute_query(
        f"SELECT {PUBLIC_COLS}, password_hash FROM people WHERE LOWER(email) = %s",
        (email,)
    )
    if not rows or not verify_password(password, rows[0].get('password_hash') or ''):
        return respond(401, {'message': 'Invalid email or password'})

    user = {k: v for k, v in rows[0].items() if k != 'password_hash'}
    # `role` mirrors system_role so the existing RBAC/UI (user.role) keeps working.
    user['role'] = user.get('system_role')
    return respond(200, {'success': True, 'user': user})


# ── Seed ─────────────────────────────────────────────────────────────────────
def normalize_status_pct(prev_status, prev_pct, in_status, in_pct):
    """Shared status<->completion rule (also enforced in the deliverables service)."""
    status = in_status if in_status is not None else prev_status
    try:
        pct = int(in_pct if in_pct is not None else prev_pct)
    except (TypeError, ValueError):
        pct = int(prev_pct or 0)
    pct = max(0, min(100, pct))

    status_set = in_status is not None and in_status != prev_status
    pct_set = in_pct is not None and int(in_pct) != int(prev_pct or 0)

    if status_set and status == 'completed':
        pct = 100
    elif pct_set and pct == 100:
        status = 'completed'
    elif pct_set and pct < 100 and status == 'completed':
        status = 'in_progress'
    elif status_set and status != 'completed' and pct == 100:
        pct = 99

    if status == 'completed':
        pct = 100
    return status, max(0, min(100, pct))


def ensure_related_tables():
    """Create projects/deliverables/budget tables so seeding works even on a fresh DB."""
    execute_query("""
        CREATE TABLE IF NOT EXISTS projects (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            name VARCHAR(255) NOT NULL, description TEXT DEFAULT '',
            status VARCHAR(50) DEFAULT 'planning', department VARCHAR(255) DEFAULT '',
            manager VARCHAR(255) DEFAULT '', start_date DATE, end_date DATE,
            budget_planned DECIMAL(15,2) DEFAULT 0, budget_spent DECIMAL(15,2) DEFAULT 0,
            completion_percentage INTEGER DEFAULT 0, priority VARCHAR(50) DEFAULT 'medium',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    execute_query("""
        CREATE TABLE IF NOT EXISTS deliverables (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            project_id UUID, project_name VARCHAR(255) DEFAULT '',
            name VARCHAR(255) NOT NULL, description TEXT DEFAULT '',
            status VARCHAR(50) DEFAULT 'pending', due_date DATE,
            assigned_to VARCHAR(255) DEFAULT '', depends_on UUID,
            completion_percentage INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    execute_query("""
        CREATE TABLE IF NOT EXISTS budget_entries (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            project_id UUID, project_name VARCHAR(255) DEFAULT '',
            category VARCHAR(255) NOT NULL, description TEXT DEFAULT '',
            planned_amount DECIMAL(15,2) DEFAULT 0, actual_amount DECIMAL(15,2) DEFAULT 0,
            entry_date DATE DEFAULT CURRENT_DATE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")


def do_seed():
    init_db()
    ensure_related_tables()

    # Fresh start.
    execute_query("TRUNCATE people, projects, deliverables, budget_entries")

    # 1) People (hash passwords; allocations applied after we know names).
    people_by_eid = {}
    for p in seed_data.PEOPLE:
        rows = execute_query("""
            INSERT INTO people
                (employee_id, name, email, password_hash, system_role, title,
                 department, capacity_hours, allocated_hours, projects)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,0,'')
            RETURNING id, employee_id, name
        """, (
            p['employee_id'], p['name'], p['email'], hash_password(p['password']),
            p['system_role'], p['title'], p['department'], int(p['capacity_hours']),
        ))
        people_by_eid[p['employee_id']] = rows[0]

    # 2) Projects.
    project_by_key = {}
    for pr in seed_data.PROJECTS:
        rows = execute_query("""
            INSERT INTO projects
                (name, description, status, department, manager,
                 start_date, end_date, budget_planned, priority)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
            RETURNING id, name
        """, (
            pr['name'], pr['description'], pr['status'], pr['department'], pr['manager'],
            pr['start_date'], pr['end_date'], float(pr['budget_planned']), pr['priority'],
        ))
        project_by_key[pr['key']] = rows[0]

    # 3) Deliverables (two passes so depends_on can reference sibling UUIDs).
    deliverable_id_by_key = {}
    for d in seed_data.DELIVERABLES:
        proj = project_by_key[d['project']]
        status, pct = normalize_status_pct('pending', 0, d['status'], d['completion_percentage'])
        rows = execute_query("""
            INSERT INTO deliverables
                (project_id, project_name, name, description, status,
                 due_date, assigned_to, completion_percentage)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
            RETURNING id
        """, (
            proj['id'], proj['name'], d['name'], d['description'], status,
            d['due_date'], d['assigned_to'], pct,
        ))
        deliverable_id_by_key[d['key']] = rows[0]['id']

    for d in seed_data.DELIVERABLES:
        if d.get('depends_on'):
            execute_query(
                "UPDATE deliverables SET depends_on = %s WHERE id = %s",
                (deliverable_id_by_key[d['depends_on']], deliverable_id_by_key[d['key']]),
            )

    # 4) Budget entries.
    for b in seed_data.BUDGET:
        proj = project_by_key[b['project']]
        execute_query("""
            INSERT INTO budget_entries
                (project_id, project_name, category, description,
                 planned_amount, actual_amount, entry_date)
            VALUES (%s,%s,%s,%s,%s,%s,%s)
        """, (
            proj['id'], proj['name'], b['category'], b['description'],
            float(b['planned_amount']), float(b['actual_amount']), b['entry_date'],
        ))

    # 5) Team allocations -> people.projects CSV + allocated_hours.
    for eid, allocs in seed_data.ALLOCATIONS.items():
        csv = ', '.join(f"{project_by_key[k]['name']} ({h}h)" for k, h in allocs)
        total = sum(h for _, h in allocs)
        execute_query(
            "UPDATE people SET projects = %s, allocated_hours = %s WHERE employee_id = %s",
            (csv, total, eid),
        )

    return respond(200, {
        'message': 'Seed complete',
        'counts': {
            'people': len(seed_data.PEOPLE),
            'projects': len(seed_data.PROJECTS),
            'deliverables': len(seed_data.DELIVERABLES),
            'budget_entries': len(seed_data.BUDGET),
        },
    })


# ── CRUD ─────────────────────────────────────────────────────────────────────
def create_person(body):
    employee_id = (body.get('employee_id') or '').strip() or next_employee_id()
    pw = body.get('password')
    pw_hash = hash_password(pw) if pw else hash_password('ChangeMe@ACME')
    role = body.get('system_role') or body.get('role') or 'member'
    if role not in VALID_ROLES:
        role = 'member'
    rows = execute_query("""
        INSERT INTO people
            (employee_id, name, email, password_hash, system_role, title,
             department, capacity_hours, allocated_hours, projects)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        RETURNING """ + PUBLIC_COLS, (
        employee_id,
        body.get('name', 'Team Member'),
        (body.get('email') or '').strip().lower(),
        pw_hash, role,
        body.get('title', ''),
        body.get('department', ''),
        int(body.get('capacity_hours') or 40),
        int(body.get('allocated_hours') or 0),
        body.get('projects', ''),
    ))
    return respond(201, rows[0] if rows else {})


def update_person(item_id, body):
    editable = ['employee_id', 'name', 'email', 'system_role', 'title',
                'department', 'capacity_hours', 'allocated_hours', 'projects']
    sets, params = [], []
    for f in editable:
        if f in body:
            val = body[f]
            if f == 'system_role' and val not in VALID_ROLES:
                continue
            if f == 'email' and isinstance(val, str):
                val = val.strip().lower()
            sets.append(f"{f} = %s")
            params.append(val)
    # Optional password change — only if a non-empty password is supplied.
    if body.get('password'):
        sets.append("password_hash = %s")
        params.append(hash_password(body['password']))
    if not sets:
        return respond(400, {'message': 'No updatable fields provided'})
    sets.append("updated_at = CURRENT_TIMESTAMP")
    params.append(item_id)
    rows = execute_query(
        f"UPDATE people SET {', '.join(sets)} WHERE id = %s RETURNING {PUBLIC_COLS}",
        params
    )
    return respond(200, rows[0] if rows else {})


def handler(event, context):
    try:
        method = get_method(event)
        if method == 'OPTIONS':
            return respond(200, {})

        init_db()
        tail = path_tail(event)
        body = json.loads(event['body']) if event.get('body') else {}

        # Sub-actions (matched before treating the tail as an id).
        if method == 'POST' and tail == 'login':
            return do_login(body)
        if method == 'POST' and tail == 'seed':
            return do_seed()

        item_id = tail if (tail and UUID_RE.match(tail)) else None
        qp = event.get('queryStringParameters') or {}

        if method == 'GET':
            if item_id:
                rows = execute_query(
                    f"SELECT {PUBLIC_COLS} FROM people WHERE id = %s", (item_id,))
                return respond(200, rows[0]) if rows else respond(404, {'message': 'Not found'})

            conds, params = [], []
            if qp.get('department'):
                conds.append("department = %s")
                params.append(qp['department'])
            if qp.get('system_role'):
                conds.append("system_role = %s")
                params.append(qp['system_role'])
            if qp.get('search'):
                conds.append("(name ILIKE %s OR email ILIKE %s OR title ILIKE %s OR employee_id ILIKE %s)")
                s = f"%{qp['search']}%"
                params += [s, s, s, s]
            where = f"WHERE {' AND '.join(conds)}" if conds else ""
            rows = execute_query(
                f"SELECT {PUBLIC_COLS} FROM people {where} ORDER BY employee_id ASC",
                params or None
            )
            return respond(200, rows)

        if method == 'POST':
            return create_person(body)

        if method == 'PUT' and item_id:
            return update_person(item_id, body)

        if method == 'DELETE' and item_id:
            execute_query("DELETE FROM people WHERE id = %s", (item_id,))
            return respond(200, {'message': 'Person deleted'})

        return respond(405, {'message': 'Method not allowed'})

    except Exception as e:
        return respond(500, {'message': str(e)})
