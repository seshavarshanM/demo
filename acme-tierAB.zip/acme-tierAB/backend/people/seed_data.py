"""
Canonical seed data for the ACME workshop — the SINGLE source of truth.

This module has NO external dependencies on purpose: both the `people`
Lambda (which hashes the passwords and inserts rows) and the offline
credentials-sheet generator import the very same lists, so the login
passwords printed on the handout can never drift from what is stored.

Plain-text passwords live here only so the seeder can hash them. They are
never written to the database (only PBKDF2 hashes are) and never returned
by any API. This is seed/demo data for a training workshop.
"""

# ─────────────────────────────────────────────────────────────────────────────
# PEOPLE — 1 admin, 3 managers, 6 members
#   system_role drives RBAC (admin | manager | member)
#   title is the human job title (separate from system_role)
# ─────────────────────────────────────────────────────────────────────────────
PEOPLE = [
    # ── Admin ────────────────────────────────────────────────────────────────
    {
        "employee_id": "ACME-0001",
        "name": "Alice Anderson",
        "email": "alice.anderson@acme.com",
        "system_role": "admin",
        "title": "Platform Administrator",
        "department": "IT",
        "capacity_hours": 40,
        "password": "Aardvark-Lantern-71",
    },
    # ── Managers ─────────────────────────────────────────────────────────────
    {
        "employee_id": "ACME-0002",
        "name": "Marcus Bennett",
        "email": "marcus.bennett@acme.com",
        "system_role": "manager",
        "title": "Engineering Manager",
        "department": "Engineering",
        "capacity_hours": 40,
        "password": "Basalt-Meadow-38",
    },
    {
        "employee_id": "ACME-0003",
        "name": "Priya Sharma",
        "email": "priya.sharma@acme.com",
        "system_role": "manager",
        "title": "Product Manager",
        "department": "Product",
        "capacity_hours": 40,
        "password": "Cobalt-Harbor-52",
    },
    {
        "employee_id": "ACME-0004",
        "name": "David Okafor",
        "email": "david.okafor@acme.com",
        "system_role": "manager",
        "title": "Delivery Manager",
        "department": "Operations",
        "capacity_hours": 40,
        "password": "Dune-Falcon-94",
    },
    # ── Members ──────────────────────────────────────────────────────────────
    {
        "employee_id": "ACME-0005",
        "name": "Sofia Rossi",
        "email": "sofia.rossi@acme.com",
        "system_role": "member",
        "title": "Senior Backend Engineer",
        "department": "Engineering",
        "capacity_hours": 40,
        "password": "Ember-Willow-16",
    },
    {
        "employee_id": "ACME-0006",
        "name": "Liam Chen",
        "email": "liam.chen@acme.com",
        "system_role": "member",
        "title": "Frontend Engineer",
        "department": "Engineering",
        "capacity_hours": 40,
        "password": "Frost-Cedar-83",
    },
    {
        "employee_id": "ACME-0007",
        "name": "Emma Johnson",
        "email": "emma.johnson@acme.com",
        "system_role": "member",
        "title": "UX Designer",
        "department": "Product",
        "capacity_hours": 36,
        "password": "Gale-Marble-27",
    },
    {
        "employee_id": "ACME-0008",
        "name": "Noah Williams",
        "email": "noah.williams@acme.com",
        "system_role": "member",
        "title": "QA Engineer",
        "department": "Engineering",
        "capacity_hours": 40,
        "password": "Harbor-Quartz-60",
    },
    {
        "employee_id": "ACME-0009",
        "name": "Ava Martinez",
        "email": "ava.martinez@acme.com",
        "system_role": "member",
        "title": "Data Analyst",
        "department": "Product",
        "capacity_hours": 32,
        "password": "Iris-Timber-45",
    },
    {
        "employee_id": "ACME-0010",
        "name": "Ethan Brown",
        "email": "ethan.brown@acme.com",
        "system_role": "member",
        "title": "DevOps Engineer",
        "department": "Operations",
        "capacity_hours": 40,
        "password": "Jasper-Canyon-09",
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# PROJECTS — manager stored as a person NAME (matches the manager-name matching
# used by the dashboards). Completion is NOT seeded: it is derived server-side
# from each project's deliverables (Tier A).
# ─────────────────────────────────────────────────────────────────────────────
PROJECTS = [
    {
        "key": "portal",
        "name": "Customer Portal Revamp",
        "description": "Rebuild the self-service customer portal on the new design system.",
        "status": "active",
        "department": "Engineering",
        "manager": "Marcus Bennett",
        "start_date": "2026-05-01",
        "end_date": "2026-10-31",
        "budget_planned": 250000,
        "priority": "high",
    },
    {
        "key": "mobile",
        "name": "Mobile App Launch",
        "description": "Ship the first native iOS and Android apps for ACME customers.",
        "status": "active",
        "department": "Product",
        "manager": "Priya Sharma",
        "start_date": "2026-04-15",
        "end_date": "2026-09-30",
        "budget_planned": 400000,
        "priority": "critical",
    },
    {
        "key": "warehouse",
        "name": "Data Warehouse Migration",
        "description": "Migrate reporting workloads to the new cloud data warehouse.",
        "status": "planning",
        "department": "Operations",
        "manager": "David Okafor",
        "start_date": "2026-08-01",
        "end_date": "2027-01-31",
        "budget_planned": 300000,
        "priority": "medium",
    },
    {
        "key": "billing",
        "name": "Billing System Upgrade",
        "description": "Replace the legacy billing engine and reconcile invoicing.",
        "status": "at_risk",
        "department": "Engineering",
        "manager": "Marcus Bennett",
        "start_date": "2026-03-01",
        "end_date": "2026-07-31",
        "budget_planned": 180000,
        "priority": "high",
    },
    {
        "key": "analytics",
        "name": "Marketing Analytics Dashboard",
        "description": "Self-serve dashboards for campaign performance and attribution.",
        "status": "active",
        "department": "Product",
        "manager": "Priya Sharma",
        "start_date": "2026-06-01",
        "end_date": "2026-11-30",
        "budget_planned": 120000,
        "priority": "medium",
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# DELIVERABLES — grouped by project key.
#   status/completion are seeded already consistent, and are additionally run
#   through the same status<->completion normalizer at seed time (Tier A).
#   depends_on references another deliverable's `key` within the same project;
#   the seeder resolves keys to the freshly-inserted UUIDs.
# ─────────────────────────────────────────────────────────────────────────────
DELIVERABLES = [
    # Customer Portal Revamp
    {"key": "portal-design", "project": "portal", "name": "Design system & wireframes",
     "description": "Component library and annotated wireframes.", "status": "completed",
     "due_date": "2026-05-30", "assigned_to": "Emma Johnson", "completion_percentage": 100,
     "depends_on": None},
    {"key": "portal-api", "project": "portal", "name": "Portal API endpoints",
     "description": "Account, billing, and profile REST endpoints.", "status": "in_progress",
     "due_date": "2026-08-15", "assigned_to": "Sofia Rossi", "completion_percentage": 60,
     "depends_on": "portal-design"},
    {"key": "portal-ui", "project": "portal", "name": "Portal UI build",
     "description": "React screens wired to the portal API.", "status": "in_progress",
     "due_date": "2026-09-20", "assigned_to": "Liam Chen", "completion_percentage": 35,
     "depends_on": "portal-api"},

    # Mobile App Launch
    {"key": "mobile-spec", "project": "mobile", "name": "Product spec & flows",
     "description": "Feature spec and primary user flows.", "status": "completed",
     "due_date": "2026-05-10", "assigned_to": "Emma Johnson", "completion_percentage": 100,
     "depends_on": None},
    {"key": "mobile-backend", "project": "mobile", "name": "Mobile BFF service",
     "description": "Backend-for-frontend aggregation service.", "status": "in_progress",
     "due_date": "2026-07-31", "assigned_to": "Sofia Rossi", "completion_percentage": 50,
     "depends_on": "mobile-spec"},
    {"key": "mobile-app", "project": "mobile", "name": "iOS & Android build",
     "description": "Cross-platform app implementation.", "status": "in_progress",
     "due_date": "2026-09-01", "assigned_to": "Liam Chen", "completion_percentage": 25,
     "depends_on": "mobile-backend"},
    {"key": "mobile-qa", "project": "mobile", "name": "Release QA & store submission",
     "description": "Regression pass and app-store submission.", "status": "pending",
     "due_date": "2026-09-25", "assigned_to": "Noah Williams", "completion_percentage": 0,
     "depends_on": "mobile-app"},

    # Data Warehouse Migration
    {"key": "warehouse-audit", "project": "warehouse", "name": "Source data audit",
     "description": "Catalogue and profile source systems.", "status": "in_progress",
     "due_date": "2026-08-31", "assigned_to": "Ava Martinez", "completion_percentage": 20,
     "depends_on": None},
    {"key": "warehouse-pipeline", "project": "warehouse", "name": "ETL pipelines",
     "description": "Build and validate ingestion pipelines.", "status": "pending",
     "due_date": "2026-11-15", "assigned_to": "Ethan Brown", "completion_percentage": 0,
     "depends_on": "warehouse-audit"},

    # Billing System Upgrade (at risk)
    {"key": "billing-engine", "project": "billing", "name": "New billing engine",
     "description": "Core rating and invoicing engine.", "status": "in_progress",
     "due_date": "2026-07-15", "assigned_to": "Sofia Rossi", "completion_percentage": 45,
     "depends_on": None},
    {"key": "billing-migrate", "project": "billing", "name": "Invoice data migration",
     "description": "Migrate and reconcile historical invoices.", "status": "in_progress",
     "due_date": "2026-07-25", "assigned_to": "Ava Martinez", "completion_percentage": 30,
     "depends_on": "billing-engine"},
    {"key": "billing-qa", "project": "billing", "name": "Reconciliation QA",
     "description": "Verify totals against the legacy system.", "status": "pending",
     "due_date": "2026-07-30", "assigned_to": "Noah Williams", "completion_percentage": 0,
     "depends_on": "billing-migrate"},

    # Marketing Analytics Dashboard
    {"key": "analytics-model", "project": "analytics", "name": "Attribution data model",
     "description": "Campaign attribution schema and metrics.", "status": "completed",
     "due_date": "2026-06-30", "assigned_to": "Ava Martinez", "completion_percentage": 100,
     "depends_on": None},
    {"key": "analytics-dash", "project": "analytics", "name": "Dashboard build",
     "description": "Self-serve dashboards and filters.", "status": "in_progress",
     "due_date": "2026-10-15", "assigned_to": "Liam Chen", "completion_percentage": 40,
     "depends_on": "analytics-model"},
]

# ─────────────────────────────────────────────────────────────────────────────
# BUDGET ENTRIES — grouped by project key. Planned sums stay UNDER each
# project's ceiling (budget_planned) so a clean seed shows no violation; the
# ceiling warning (Tier A) is demonstrable by adding one more large entry.
# ─────────────────────────────────────────────────────────────────────────────
BUDGET = [
    # portal — ceiling 250,000; planned total 210,000
    {"project": "portal", "category": "Personnel", "description": "Engineering salaries",
     "planned_amount": 150000, "actual_amount": 82000, "entry_date": "2026-05-15"},
    {"project": "portal", "category": "Infrastructure", "description": "Hosting & CDN",
     "planned_amount": 40000, "actual_amount": 15000, "entry_date": "2026-06-01"},
    {"project": "portal", "category": "Tooling", "description": "Design & QA tooling",
     "planned_amount": 20000, "actual_amount": 12000, "entry_date": "2026-06-10"},

    # mobile — ceiling 400,000; planned total 355,000
    {"project": "mobile", "category": "Personnel", "description": "App & backend team",
     "planned_amount": 260000, "actual_amount": 120000, "entry_date": "2026-05-01"},
    {"project": "mobile", "category": "Vendor", "description": "Design agency",
     "planned_amount": 60000, "actual_amount": 60000, "entry_date": "2026-05-20"},
    {"project": "mobile", "category": "Marketing", "description": "Launch campaign",
     "planned_amount": 35000, "actual_amount": 5000, "entry_date": "2026-07-01"},

    # warehouse — ceiling 300,000; planned total 230,000
    {"project": "warehouse", "category": "Infrastructure", "description": "Warehouse compute",
     "planned_amount": 140000, "actual_amount": 0, "entry_date": "2026-08-05"},
    {"project": "warehouse", "category": "Vendor", "description": "Migration consultants",
     "planned_amount": 90000, "actual_amount": 0, "entry_date": "2026-08-10"},

    # billing — ceiling 180,000; planned total 165,000
    {"project": "billing", "category": "Personnel", "description": "Billing squad",
     "planned_amount": 120000, "actual_amount": 98000, "entry_date": "2026-03-15"},
    {"project": "billing", "category": "Operations", "description": "Cutover & support",
     "planned_amount": 45000, "actual_amount": 41000, "entry_date": "2026-06-20"},

    # analytics — ceiling 120,000; planned total 98,000
    {"project": "analytics", "category": "Personnel", "description": "Analytics build",
     "planned_amount": 78000, "actual_amount": 44000, "entry_date": "2026-06-10"},
    {"project": "analytics", "category": "Tooling", "description": "BI licenses",
     "planned_amount": 20000, "actual_amount": 18000, "entry_date": "2026-06-15"},
]

# ─────────────────────────────────────────────────────────────────────────────
# TEAM ALLOCATIONS — employee_id -> list of (project key, hours/week).
# The seeder writes these into each person's `projects` CSV as "Name (Xh)" and
# sets allocated_hours to the sum, so ProjectDetail's capacity logic and the
# Profile page both light up. Sums stay at/under each person's capacity.
# ─────────────────────────────────────────────────────────────────────────────
ALLOCATIONS = {
    "ACME-0005": [("portal", 20), ("mobile", 10), ("billing", 8)],   # Sofia  38/40
    "ACME-0006": [("portal", 16), ("mobile", 12), ("analytics", 10)],# Liam   38/40
    "ACME-0007": [("portal", 12), ("mobile", 10)],                   # Emma   22/36
    "ACME-0008": [("mobile", 12), ("billing", 10)],                  # Noah   22/40
    "ACME-0009": [("warehouse", 12), ("billing", 10), ("analytics", 8)], # Ava 30/32
    "ACME-0010": [("warehouse", 16)],                               # Ethan  16/40
}
