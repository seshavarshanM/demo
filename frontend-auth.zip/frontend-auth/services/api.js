import axios from 'axios'

// The proxy routes everything under /api/{endpoint}; normalise either form.
const RAW = import.meta.env.VITE_API_URL || 'http://localhost:3001'
const BASE_URL = RAW.endsWith('/api') ? RAW : `${RAW.replace(/\/$/, '')}/api`

const STORAGE_KEY = 'acme_session'

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000,
})

/**
 * Attach the JWT at request time.
 *
 * Reading from sessionStorage here (rather than setting a default header in a
 * React effect) avoids a race: child components fire their data effects before
 * the provider's effect runs, so a default set in the provider would be missing
 * on the very first requests after a page load.
 */
api.interceptors.request.use(config => {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY)
    const token = raw ? JSON.parse(raw)?.token : null
    if (token) config.headers.Authorization = `Bearer ${token}`
  } catch {
    /* no session — request goes out unauthenticated and the API will answer 401 */
  }
  return config
})

/**
 * A 401 means the session is gone or expired. Clear it and send the user back
 * to sign in, rather than leaving the app in a half-broken state.
 */
api.interceptors.response.use(
  response => response,
  error => {
    const status = error?.response?.status
    const isLoginCall = error?.config?.url?.includes('/login')
    if (status === 401 && !isLoginCall) {
      sessionStorage.removeItem(STORAGE_KEY)
      if (!window.location.pathname.startsWith('/login')) {
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

export default api
